import { createPortal } from 'react-dom';
import React, { useEffect, useRef, useState } from 'react';
import { Check, Copy, ExternalLink, Loader2, X } from 'lucide-react';
import type { NuvioStreamOption } from '../api/types.ts';
import { copyTextNow } from './torrent-search/webtor.ts';
import { audioFromFilename, browserAudioTracks, currentPlatform, hasHeavyAudio, mxPlayerLink, playsSilently, vlcLink, type BrowserAudioTrack } from './torrent-search/hdPlayer.ts';

/**
 * Play HD: tries the file in the browser. If the browser cannot decode it (HEVC / DTS are common in these files) or it
 * plays without sound, the message and the "Open in" links offer VLC and MX Player, which play everything.
 */
export const HdPlayerModal: React.FC<{ title: string; option: NuvioStreamOption; onClose: () => void }> = ({ title, option, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [state, setState] = useState<'loading' | 'playing' | 'failed' | 'silent'>('loading');
  const [copied, setCopied] = useState(false);
  const [tracks, setTracks] = useState<BrowserAudioTrack[]>([]);
  const platform = currentPlatform();
  const vlc = vlcLink(option.url, platform);
  const mx = mxPlayerLink(option.url, platform);
  const advertised = audioFromFilename(option.filename);
  const heavyAudio = hasHeavyAudio(option.filename);
  const pickTrack = (id: string) => {
    const list = (videoRef.current as unknown as { audioTracks?: ArrayLike<{ id?: string; enabled: boolean }> } | null)?.audioTracks;
    if (!list) return;
    for (let index = 0; index < list.length; index += 1) list[index].enabled = String(list[index].id ?? index) === id;
    setTracks(browserAudioTracks(videoRef.current));
  };

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => { if (event.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  useEffect(() => {
    if (state !== 'playing') return undefined;
    const timer = window.setInterval(() => {
      const video = videoRef.current;
      if (video && !video.paused && playsSilently(video)) setState('silent');
    }, 1500);
    return () => window.clearInterval(timer);
  }, [state]);

  const linkClass = 'inline-flex items-center gap-1 rounded-lg border border-slate-600 bg-slate-800 px-3 py-1.5 text-xs font-semibold text-slate-100 hover:bg-slate-700';
  const problem = state === 'failed'
    ? 'This browser cannot play this file (the video or audio format is not supported).'
    : state === 'silent' ? 'The video plays but has no sound in this browser (the audio format is not supported).' : '';

  return createPortal(
    <div className="fixed inset-0 z-[110] flex items-center justify-center bg-black/80 p-3" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
      <section role="dialog" aria-modal="true" aria-label={`Play ${title}`} className="flex max-h-[92vh] w-full max-w-3xl flex-col overflow-hidden rounded-2xl border border-slate-700 bg-slate-950 shadow-2xl">
        <header className="flex items-start justify-between gap-3 border-b border-slate-800 px-4 py-2.5">
          <div className="min-w-0">
            <h2 className="truncate text-sm font-bold text-slate-100">{title}</h2>
            <p className="truncate text-[11px] text-slate-400" title={option.filename}>{option.label}</p>
          </div>
          <button type="button" onClick={onClose} aria-label="Close player" className="shrink-0 rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"><X className="h-4 w-4" /></button>
        </header>
        <div className="relative bg-black">
          <video
            ref={videoRef}
            src={option.url}
            controls
            autoPlay
            playsInline
            preload="metadata"
            className="max-h-[60vh] w-full"
            onPlaying={() => setState(previous => (previous === 'silent' ? previous : 'playing'))}
            onError={() => setState('failed')}
            onLoadedMetadata={() => setTracks(browserAudioTracks(videoRef.current))}
          />
          {state === 'loading' && <div className="pointer-events-none absolute inset-0 flex items-center justify-center text-slate-300"><Loader2 className="h-6 w-6 animate-spin" /></div>}
        </div>
        <div className="space-y-2 px-4 py-3">
          {tracks.length > 1 ? (
            <label className="flex items-center gap-2 text-[11px] text-slate-300">
              <span className="font-semibold uppercase tracking-wide text-slate-500">Audio</span>
              <select value={tracks.find(track => track.enabled)?.id ?? tracks[0].id} onChange={event => pickTrack(event.target.value)}
                className="min-w-0 flex-1 rounded-lg border border-slate-700 bg-slate-900 px-2 py-1.5 text-xs text-slate-100 outline-none focus:border-cyan-500" aria-label="Audio track">
                {tracks.map((track, index) => (
                  <option key={track.id} value={track.id}>{track.label || track.language || `Track ${index + 1}`}{track.language && track.label ? ` · ${track.language}` : ''}</option>
                ))}
              </select>
            </label>
          ) : advertised.length > 1 ? (
            <p className="text-[11px] leading-snug text-slate-400">
              This file has {advertised.length} audio tracks: {advertised.map(track => track.label).join(', ')}. This browser cannot switch between them;
              open it in VLC to choose the audio track.
            </p>
          ) : null}
          {problem && <div role="alert" className="rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-xs text-amber-200">{problem} Open it in a player app instead:</div>}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[11px] text-slate-500">Open in</span>
            {vlc && <a href={vlc} className={linkClass} title="Plays every audio format and lets you choose the track"><ExternalLink className="h-3.5 w-3.5" />VLC (recommended)</a>}
            {mx && <a href={mx} className={linkClass}><ExternalLink className="h-3.5 w-3.5" />MX Player</a>}
            <button type="button" className={linkClass} onClick={() => { if (copyTextNow(option.url)) { setCopied(true); window.setTimeout(() => setCopied(false), 2000); } }}>
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}Copy link
            </button>
          </div>
          {mx && heavyAudio && <p className="text-[10px] leading-snug text-amber-300/90">This file has Dolby Digital Plus / DTS audio. MX Player often plays it without sound; VLC plays it and lets you switch tracks.</p>}
          {platform === 'desktop' && <p className="text-[10px] text-slate-500">On a computer, paste the copied link in VLC: Media → Open Network Stream.</p>}
        </div>
      </section>
    </div>,
    document.body,
  );
};
