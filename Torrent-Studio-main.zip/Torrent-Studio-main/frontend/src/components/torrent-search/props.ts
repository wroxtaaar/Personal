import { TorrentSearchResult } from '../../api/client.ts';

export type SeedrSearchFile = {
  id: string;
  streamId?: string;
  name: string;
  size: number;
  folderId: string;
  folderPath: string;
};


export interface TorrentSearchPanelProps {
  onPrepare: (
    result: TorrentSearchResult,
    metadata?: {
      name: string;
      hash: string;
      files: { index: number; name: string; size: number; path: string; type: string; priority?: number }[];
      totalSize: number;
    },
    /** Seedr folders of the same movie to delete before the new torrent is added. */
    options?: { replaceFolderIds?: string[] }
  ) => Promise<{ files: SeedrSearchFile[]; deletedFolderIds?: string[] }>;
  onCancelPrepare?: () => void | Promise<void>;
  onOpenProgress?: () => void;
  seedrFiles?: SeedrSearchFile[];
  seedrDeletedFolderIds?: string[];
  onPlaySeedrFile?: (file: SeedrSearchFile) => void | Promise<void>;
}
