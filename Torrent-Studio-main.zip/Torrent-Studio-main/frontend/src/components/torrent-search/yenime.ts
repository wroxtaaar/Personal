export function validMalId(value: unknown): value is number {
  const id = typeof value === 'number' ? value : Number(String(value ?? '').trim());
  return Number.isInteger(id) && id > 0;
}

export function validEpisode(value: unknown): value is number {
  const episode = typeof value === 'number' ? value : Number(String(value ?? '').trim());
  return Number.isInteger(episode) && episode > 0;
}

export function buildYenimeUrl(malId: unknown, episode: unknown, type: 'sub' | 'dub' = 'dub'): string {
  if (!validMalId(malId)) throw new Error('A positive MAL ID is required.');
  if (!validEpisode(episode)) throw new Error('A positive episode number is required.');
  if (type !== 'sub' && type !== 'dub') throw new Error('Stream type must be sub or dub.');
  const baseUrl = `https://player.yenime.net/anime/mal/${Number(malId)}/${Number(episode)}`;
  return type === 'dub' ? `${baseUrl}?dub=1` : baseUrl;
}

export const YENIME_ANIME_MAL_IDS: Record<string, number> = {
  'Fullmetal Alchemist: Brotherhood': 5114,
};

export function yenimeMalIdForTitle(title: string): number | undefined {
  return YENIME_ANIME_MAL_IDS[title];
}

export function isAnimeCatalogue(catalogue: string | null | undefined): boolean {
  return catalogue === 'classics-anime';
}

/**
 * Series kept in the Anime lists that are Western animation, not anime: they have no MAL id, so Yenime cannot play them.
 * They open the normal episode picker (VidRift / NexStream) instead. TMDB series ids.
 */
export const NON_ANIME_TV_IDS = new Set<number>([246, 33880]);   // Avatar: The Last Airbender, The Legend of Korra

export const isNonAnimeShow = (show: { id?: number | string | null; tmdbId?: number | string | null }): boolean =>
  NON_ANIME_TV_IDS.has(Number(show.tmdbId ?? show.id));
