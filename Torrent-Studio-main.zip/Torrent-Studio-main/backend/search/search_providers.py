"""Moved out of main.py (see docs/main-split-plan.md)."""

import asyncio
import contextvars
import hashlib
import os
import re
import time
from datetime import datetime, timezone
from html import unescape
from typing import Any
from urllib.parse import quote, urljoin

import httpx
from bs4 import BeautifulSoup

from core.cache_diagnostics import _InstrumentedAsyncClient, _record_cache_event
from metadata.posters import _poster_url_for_release
from seedr.seedr_client import info_hash
from core.settings import (
    KNABEN_API_URL,
    MAX_SEARCH_RESULT_SIZE_BYTES,
    MIN_SEARCH_RESULT_SIZE_BYTES,
    SEARCH_CACHE_MAX_ENTRIES,
    SEARCH_CACHE_MIN_RESULTS,
    SEARCH_CACHE_SECONDS,
    SEARCH_CACHE_STALE_SECONDS,
    SEARCH_COMPOUND_ALIASES,
    SEARCH_SOURCE_TIMEOUT_SECONDS,
    SEARCH_TOTAL_TIMEOUT_SECONDS,
    YTS_API_HOSTS,
    logger,
)
from core.shared import _MANUAL_TORRENT_SEARCH

# Catalogue warm-ups query many titles at once. Keep outbound provider requests bounded.
_X1337_REQUEST_SEMAPHORE = asyncio.Semaphore(2)
_LIMETORRENTS_REQUEST_SEMAPHORE = asyncio.Semaphore(2)
_KNABEN_REQUEST_SEMAPHORE = asyncio.Semaphore(1)
_YTS_REQUEST_SEMAPHORE = asyncio.Semaphore(2)
_search_cache: dict[str, tuple[float, list[dict[str, Any]]]] = {}
_search_inflight: dict[str, asyncio.Task[list[dict[str, Any]]]] = {}


# Set by offline scans that want releases of any size (TV season packs for Webtor are 10-60 GB).
_SIZE_WINDOW_DISABLED: contextvars.ContextVar[bool] = contextvars.ContextVar("size_window_disabled", default=False)
# "all" (live search: the fast sources, then Prowlarr only when they found nothing), "fast" (never Prowlarr) or
# "prowlarr" (only Prowlarr). The cache scans run the fast pass first and a Prowlarr pass for what is left.
_SEARCH_SOURCE: contextvars.ContextVar[str] = contextvars.ContextVar("search_source", default="all")


def _in_size_window(size: Any, query: str | None = None) -> bool:
    """The movie size window (TORRENT_MIN_SIZE_MB..TORRENT_MAX_SIZE_GB). It never applies to series.

    A query that names a season or episode ("Reacher S02") is a series search: any known size is fine, because
    season packs are far bigger than a movie and the limit exists for movies only. Providers apply this to their own
    rows BEFORE sorting and truncating to ``limit``: a movie outside the window can never be shown (the final gate
    drops it anyway), so it must not take one of the ``limit`` slots that in-window releases could use.
    """
    if _SIZE_WINDOW_DISABLED.get():
        return True
    try:
        value = int(float(size or 0))
    except (TypeError, ValueError, OverflowError):
        return False
    if query is not None and _search_media_kind(query) == "tv":
        return value > 0
    return MIN_SEARCH_RESULT_SIZE_BYTES <= value <= MAX_SEARCH_RESULT_SIZE_BYTES


def _search_tokens(value: str) -> list[str]:
    return [token for token in re.findall(r"[a-z0-9]+", value.lower()) if token]


def _media_search_parts(value: str) -> tuple[str, int | None, int | None]:
    """Split a media query into title text plus optional season/episode constraints."""
    q = re.sub(r"\s+", " ", value.strip())
    season_match = re.search(r"\b(?:season|series)\s*(\d{1,2})\b", q, re.I)
    episode_match = re.search(r"\bS(\d{1,2})(?:E(\d{1,3}))?\b", q, re.I)
    season = int(season_match.group(1)) if season_match else (
        int(episode_match.group(1)) if episode_match else None
    )
    episode = (
        int(season_match.group(1)) if False else None
    )
    if episode_match and episode_match.group(2):
        episode = int(episode_match.group(2))

    title = q
    title = re.sub(r"\b(?:season|series)\s*\d{1,2}\b", " ", title, flags=re.I)
    title = re.sub(r"\bS\d{1,2}(?:E\d{1,3})?\b", " ", title, flags=re.I)
    title = re.sub(
        r"\b(?:19|20)\d{2}\b|"
        r"\b(?:2160p|1440p|1080p|720p|480p|4k|8k)\b|"
        r"\b(?:webrip|web-dl|bluray|brrip|x264|x265|h264|h265|hevc|hdr)\b",
        " ",
        title,
        flags=re.I,
    )
    title = re.sub(r"\s+", " ", title).strip()
    return title, season, episode


def _season_episode_match(title: str, season: int | None, episode: int | None) -> bool:
    if season is None:
        return True

    upper = title.upper()
    match = re.search(r"\bS(\d{1,2})(?:E(\d{1,3}))?\b", upper)
    if match:
        if int(match.group(1)) != season:
            return False
        if episode is not None and (not match.group(2) or int(match.group(2)) != episode):
            return False
        return True

    season_word = re.search(r"\bSEASON[\s._-]*(\d{1,2})\b", upper)
    if season_word:
        if int(season_word.group(1)) != season:
            return False
        return episode is None

    return False


def _tvmaze_query(value: str) -> str:
    value = re.sub(r"\bS\d{1,2}(?:E\d{1,3})?.*$", "", value, flags=re.I)
    value = re.sub(r"\b(?:season|series)\s*\d+\b", "", value, flags=re.I)
    value = re.sub(r"\b(?:19|20)\d{2}\b", "", value)
    return re.sub(r"\s+", " ", value).strip()


def _normalize_title(value: str) -> str:
    return " ".join(_search_tokens(value))


# Optional proxy used ONLY for 1337x requests (e.g. "socks5://127.0.0.1:40000" for Cloudflare WARP, or an http proxy).
# Datacenter addresses are often refused by 1337x (HTTP 403); a proxy gives it another address. Empty = direct.
X1337_PROXY = os.getenv("X1337_PROXY", "").strip() or None
X1337_CLIENT_OPTIONS: dict[str, Any] = {"proxy": X1337_PROXY} if X1337_PROXY else {}

X1337_HOSTS = [
    "1337x.to",
    "1337x.st",
    "x1337x.ws",
    "x1337x.eu",
    "x1337x.cc",
]

# 1337x subcategory IDs represented by the icon at the left of each result.
# The icon describes the release type; it is not a quality filter.
X1337_MOVIE_SUBCATEGORIES = {"1","2","3","4","42","54","55","66","70","73","76"}
X1337_TV_SUBCATEGORIES = {"5","6","7","9","41","71","74","75"}
X1337_MEDIA_SUBCATEGORIES = X1337_MOVIE_SUBCATEGORIES | X1337_TV_SUBCATEGORIES


def _x1337_rows(html_text: str) -> list[dict[str, str]]:
    """Parse 1337x search rows across mirror HTML variations."""
    soup = BeautifulSoup(html_text or "", "html.parser")
    rows: list[dict[str, str]] = []
    seen_paths: set[str] = set()

    for link in soup.find_all("a", href=re.compile(r"^/torrent/")):
        href = str(link.get("href") or "").strip()
        if not href or href in seen_paths:
            continue
        row = link.find_parent("tr")
        if row is None:
            continue
        title = link.get_text(" ", strip=True)
        if not title:
            continue
        cells = row.find_all("td")
        cell_text = [cell.get_text(" ", strip=True) for cell in cells]
        row_text = " ".join(cell_text) or row.get_text(" ", strip=True)
        size = ""
        seeders = "0"
        leechers = "0"
        for cell in cells:
            classes = " ".join(cell.get("class") or []).lower()
            text = cell.get_text(" ", strip=True)
            size_match = re.search(r"([\d.]+\s*[KMGT]i?B)", text, re.I)
            if not size and size_match:
                size = size_match.group(1)
            number = re.search(r"\d[\d,]*", text)
            if number and "seed" in classes:
                seeders = number.group(0).replace(",", "")
            elif number and ("leech" in classes or "leeches" in classes):
                leechers = number.group(0).replace(",", "")
        if not size:
            size_match = re.search(r"([\d.]+\s*[KMGT]i?B)", row_text, re.I)
            if size_match:
                size = size_match.group(1)
        numeric_cells = [re.sub(r"[^\d,]", "", text) for text in cell_text if re.fullmatch(r"\s*[\d,]+\s*", text or "")]
        if seeders == "0" and len(numeric_cells) >= 2:
            seeders = numeric_cells[-2] or "0"
        if leechers == "0" and len(numeric_cells) >= 1:
            leechers = numeric_cells[-1] or "0"
        seen_paths.add(href)
        sub_href = ""
        sub_id = ""
        if cells:
            sub_link = cells[0].find("a", href=re.compile(r"^/sub/"))
            if sub_link is not None:
                sub_href = str(sub_link.get("href") or "").strip()
                sub_match = re.search(r"^/sub/(\d+)/", sub_href)
                if sub_match:
                    sub_id = sub_match.group(1)

        rows.append({
            "title": title,
            "path": href,
            "size": size or "0 B",
            "seeders": seeders,
            "leechers": leechers,
            "subcategory_path": sub_href,
            "subcategory_id": sub_id,
        })
    return rows

async def search_1337x_direct(
    query: str,
    limit: int = 50,
    pages: int = 2,
    category: str | None = None,
    provider_query: str | None = None,
) -> list[dict[str, Any]]:
    if not _MANUAL_TORRENT_SEARCH.get():
        _record_cache_event("torrent_search", "blocked_prefilled_live_lookup")
        return []
    """Primary 1337x search using media categories and cheap listing-page scraping.

    The unsorted category route is the reliable base path. The server-side
    seeders-sorted route is fetched as an optional second listing because 1337x
    integrations document that sorted keyword searches can fail under load.
    """
    q, season, episode = _media_search_parts(query)
    if not q:
        return []
    q = re.sub(r"\s+", " ", provider_query or _media_provider_query(query)).strip()
    if not q:
        return []

    encoded = quote(q, safe="").replace("%20", "+")
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }
    # Apply the shared configured search-size window.
    minimum_size, maximum_size = MIN_SEARCH_RESULT_SIZE_BYTES, MAX_SEARCH_RESULT_SIZE_BYTES
    categories = (
        [category]
        if category in {"Movies", "TV"}
        else (["TV"] if season is not None or episode is not None else ["Movies", "TV"])
    )

    async with _InstrumentedAsyncClient(
        timeout=SEARCH_SOURCE_TIMEOUT_SECONDS,
        follow_redirects=True,
        headers=headers,
        **X1337_CLIENT_OPTIONS,
    ) as client:

        async def find_category_page(category_name: str) -> tuple[str, str]:
            # Probe only the normal category-search route. One cheap route is
            # enough to identify a usable mirror; do not serially probe both
            # normal and sorted routes across every mirror.
            path = f"/category-search/{encoded}/{category_name}/1/"
            for host in X1337_HOSTS:
                try:
                    async with _X1337_REQUEST_SEMAPHORE:
                        response = await client.get(f"https://{host}{path}")
                    if response.status_code < 400 and _x1337_rows(response.text):
                        return f"https://{host}", response.text
                except httpx.HTTPError:
                    continue
            return "", ""

        category_pages = await asyncio.gather(
            *(find_category_page(name) for name in categories),
            return_exceptions=False,
        )

        # Generic search is also queried because language searches can surface
        # Hindi/dual-audio releases there that are not near the top of a
        # category search. Every generic row is classified through /sub/<id>/
        # so non-media categories cannot leak into the app.
        generic_base = next((base for base, _ in category_pages if base), "")
        generic_pages: list[str] = []
        if generic_base:
            generic_urls = [f"{generic_base}/search/{encoded}/1/"]
            if pages > 1:
                generic_urls.append(f"{generic_base}/search/{encoded}/2/")

            async def fetch_generic(url: str) -> str:
                try:
                    async with _X1337_REQUEST_SEMAPHORE:
                        response = await client.get(url)
                    if response.status_code < 400 and _x1337_rows(response.text):
                        return response.text
                except httpx.HTTPError:
                    pass
                return ""

            generic_pages = [
                value for value in await asyncio.gather(
                    *(fetch_generic(url) for url in generic_urls),
                    return_exceptions=False,
                )
                if value
            ]

        async def fetch_category(
            category_name: str,
            base: str,
            first_page: str,
        ) -> list[dict[str, str]]:
            if not base or not first_page:
                return []

            # Normal page 1 + sorted page 1 are fetched together. Sorted is
            # treated as enrichment, never as a requirement.
            paths = [
                ("normal", first_page),
                (
                    "sorted",
                    f"{base}/sort-category-search/{encoded}/{category_name}/seeders/desc/1/",
                ),
            ]
            if pages > 1:
                paths.append((
                    "normal2",
                    f"{base}/category-search/{encoded}/{category_name}/2/",
                ))

            async def fetch_one(kind: str, value: str):
                if kind == "normal":
                    return value
                try:
                    async with _X1337_REQUEST_SEMAPHORE:
                        response = await client.get(value)
                    if response.status_code < 400 and _x1337_rows(response.text):
                        return response.text
                except httpx.HTTPError:
                    pass
                return ""

            fetched = await asyncio.gather(
                *(fetch_one(kind, value) for kind, value in paths),
                return_exceptions=False,
            )
            pages_html = [text for text in fetched if isinstance(text, str) and text]
            return pages_html

        fetched_by_category = await asyncio.gather(
            *(
                fetch_category(name, base, first_page)
                for name, (base, first_page) in zip(categories, category_pages)
            ),
            return_exceptions=False,
        )

        kind_hint = "tv" if (season is not None or episode is not None) else "both"

        async def parse_candidates(
            category_name: str,
            html_pages: list[str],
            generic_search: bool = False,
        ) -> list[dict[str, str]]:
            target = _media_provider_query(query)
            tokens = _search_tokens(target)
            compact_query = "".join(tokens)
            candidates, seen_paths = [], set()

            for html_text in html_pages:
                for row in _x1337_rows(html_text):
                    path = row.get("path") or ""
                    if not path or path in seen_paths:
                        continue
                    seen_paths.add(path)

                    normalized = _normalize_title(row["title"])
                    compact_normalized = normalized.replace(" ", "")
                    if tokens and not (
                        all(token in normalized for token in tokens)
                        or (compact_query and compact_query in compact_normalized)
                    ):
                        continue
                    if not _season_episode_match(row["title"], season, episode):
                        continue

                    if generic_search:
                        sub_id = str(row.get("subcategory_id") or "")
                        if sub_id not in X1337_MEDIA_SUBCATEGORIES:
                            continue
                        if kind_hint == "tv" and sub_id not in X1337_TV_SUBCATEGORIES:
                            continue

                    size_match = re.match(
                        r"([\d.]+)\s*([KMGT]i?B)",
                        row.get("size", ""),
                        re.IGNORECASE,
                    )
                    if not size_match:
                        continue
                    units = {
                        "KB": 1024, "KIB": 1024,
                        "MB": 1024**2, "MIB": 1024**2,
                        "GB": 1024**3, "GIB": 1024**3,
                        "TB": 1024**4, "TIB": 1024**4,
                    }
                    size = int(
                        float(size_match.group(1))
                        * units[size_match.group(2).upper()]
                    )
                    # a row from the TV category is a series: no size limit (the window is for movies only)
                    if (size <= 0) if category_name == "TV" else not minimum_size <= size <= maximum_size:
                        continue

                    row["size_bytes"] = str(size)
                    row["media_category"] = category_name
                    candidates.append(row)

            candidates.sort(
                key=lambda row: (
                    _title_relevance(row["title"], query)[0],
                    int(row.get("seeders") or 0),
                    int(row.get("leechers") or 0),
                ),
                reverse=True,
            )
            return candidates

        candidate_lists = await asyncio.gather(
            *(
                parse_candidates(name, html_pages)
                for name, html_pages in zip(categories, fetched_by_category)
            ),
            return_exceptions=False,
        )

        candidates = [
            row
            for values in candidate_lists
            for row in values
        ]

        if generic_pages:
            candidates.extend(
                await parse_candidates(
                    "TV" if kind_hint == "tv" else "Movies",
                    generic_pages,
                    generic_search=True,
                )
            )

        unique: dict[str, dict[str, str]] = {}
        for row in candidates:
            key = row.get("path") or _normalize_title(row.get("title", ""))
            unique.setdefault(key, row)

        candidates = list(unique.values())
        candidates.sort(
            key=lambda row: (
                _title_relevance(row["title"], query)[0],
                int(row.get("seeders") or 0),
                int(row.get("leechers") or 0),
            ),
            reverse=True,
        )
        # Detail pages are the expensive part. Keep lookup fan-out bounded
        # on Render Free while letting DVD/HD/HEVC/dual-audio/h.264 and other
        # valid 1337x release types compete.
        candidates = candidates[:min(max(limit, 1), 20)]

        async def fetch_detail(row):
            # Keep useful listing results even when the provider's detail page
            # is slow or blocks server-side requests. Magnets are resolved on
            # demand by /api/search/resolve-magnet when a user clicks Prepare.
            detail_url = base_for_row(row) + row["path"]
            return {
                "guid": "1337x-" + hashlib.sha1(detail_url.encode("utf-8")).hexdigest()[:20],
                "title": row["title"],
                "size": int(row["size_bytes"]),
                "seeders": int(row.get("seeders") or 0),
                "leechers": int(row.get("leechers") or 0),
                "indexer": "1337x",
                "protocol": "torrent",
                "publishDate": "",
                "magnetUrl": None,
                "infoHash": "",
                "downloadUrl": None,
                "infoUrl": detail_url,
                "sourceUrl": detail_url,
                "descriptorUrl": "",
                "category": row.get("media_category") or "Video",
            }

        # Preserve the base URL selected for each category without doing a
        # second mirror probe before opening detail pages.
        row_bases: dict[str, str] = {}
        for category_name, (base, _) in zip(categories, category_pages):
            if base:
                for row in candidate_lists[categories.index(category_name)]:
                    row_bases[row["path"]] = base

        def base_for_row(row: dict[str, str]) -> str:
            return row_bases.get(row["path"], category_pages[0][0] if category_pages else "")

        fetched = await asyncio.gather(
            *(fetch_detail(row) for row in candidates),
            return_exceptions=True,
        )
    return [item for item in fetched if isinstance(item, dict)]

async def search_yts_movies(query: str, limit: int = 50) -> list[dict[str, Any]]:
    if not _MANUAL_TORRENT_SEARCH.get():
        _record_cache_event("torrent_search", "blocked_prefilled_live_lookup")
        return []
    """Search YTS directly so movie searches are not lost in aggregate ranking."""
    movie_query = _media_provider_query(query)
    if not movie_query:
        return []

    payload = None
    async with _InstrumentedAsyncClient(timeout=12, follow_redirects=True) as client:
        for host in YTS_API_HOSTS:
            try:
                async with _YTS_REQUEST_SEMAPHORE:
                    response = await client.get(
                        f"https://{host}/api/v2/list_movies.json",
                        params={"query_term": movie_query, "limit": "50"},
                        headers={"Accept": "application/json"},
                    )
                response.raise_for_status()
                parsed = response.json()
                if isinstance(parsed, dict):
                    payload = parsed
                    break
            except (httpx.HTTPError, ValueError):
                continue

    if not isinstance(payload, dict):
        return []

    target_tokens = _search_tokens(movie_query)
    results: list[dict[str, Any]] = []
    for movie in (payload.get("data") or {}).get("movies") or []:
        if not isinstance(movie, dict):
            continue
        title = str(movie.get("title_long") or movie.get("title") or "").strip()
        if not title:
            continue
        title_tokens = _normalize_title(title)
        if target_tokens and not all(token in title_tokens for token in target_tokens):
            continue

        released = movie.get("date_uploaded_unix")
        try:
            from datetime import datetime, timezone
            published = datetime.fromtimestamp(
                int(released), tz=timezone.utc
            ).isoformat() if released else ""
        except Exception:
            published = ""

        for torrent in movie.get("torrents") or []:
            if not isinstance(torrent, dict):
                continue
            h = str(torrent.get("hash") or "").strip().lower()
            if not re.fullmatch(r"[0-9a-f]{40}", h):
                continue
            quality = str(torrent.get("quality") or "").strip()
            kind = str(torrent.get("type") or "").strip()
            suffix = " ".join(x for x in (quality, kind) if x)
            display_title = f"{title} [{suffix}]" if suffix else title
            magnet = (
                f"magnet:?xt=urn:btih:{h}&dn={quote(display_title, safe='')}"
            )
            for tracker in (
                "udp://tracker.opentrackr.org:1337/announce",
                "udp://open.stealth.si:80/announce",
            ):
                magnet += "&tr=" + quote(tracker, safe="")

            results.append({
                "guid": f"yts-{h}",
                "title": display_title,
                "mediaTitle": title,
                "year": int(movie.get("year") or 0) or None,
                "rating": float(movie.get("rating") or 0) or None,
                "genres": [str(g).strip() for g in (movie.get("genres") or []) if str(g).strip()],
                "posterUrl": f"/api/poster?title={quote(title, safe='')}&year={quote(str(movie.get('year') or ''), safe='')}",
                "quality": suffix,
                "size": int(float(torrent.get("size_bytes") or 0)),
                "seeders": int(torrent.get("seeds") or 0),
                "leechers": int(torrent.get("peers") or 0),
                "indexer": "yts.mx",
                "protocol": "torrent",
                "publishDate": published,
                "magnetUrl": magnet,
                "infoHash": h,
                "downloadUrl": magnet,
                "infoUrl": "",
                "sourceUrl": "",
            })

    results = [row for row in results if _in_size_window(row.get("size"))]
    results.sort(
        key=lambda row: (row["seeders"] + row["leechers"], row["publishDate"]),
        reverse=True,
    )
    return results[:limit]


async def search_tv_eztv(query: str, limit: int = 30) -> list[dict[str, Any]]:
    tv_query, _season, _episode = _media_search_parts(query)
    tv_query = _tvmaze_query(tv_query)
    if not tv_query:
        return []

    try:
        async with _InstrumentedAsyncClient(timeout=12, follow_redirects=True) as client:
            response = await client.get(
                "https://api.tvmaze.com/search/shows",
                params={"q": tv_query},
                headers={"Accept": "application/json"},
            )
            response.raise_for_status()
            matches = response.json()
    except (httpx.HTTPError, ValueError):
        return []

    if not isinstance(matches, list):
        return []

    target = _normalize_title(tv_query)
    imdb_id = ""
    for match in matches[:10]:
        show = match.get("show") if isinstance(match, dict) else None
        if not isinstance(show, dict):
            continue
        name = str(show.get("name") or "").strip()
        external = show.get("externals")
        candidate = str(external.get("imdb") or "").strip() if isinstance(external, dict) else ""
        if candidate and _normalize_title(name) == target:
            imdb_id = candidate
            break

    if not imdb_id:
        return []

    payload: dict[str, Any] | None = None
    async with _InstrumentedAsyncClient(timeout=15, follow_redirects=True) as client:
        for host in ("eztv.yt", "eztvx.to"):
            try:
                response = await client.get(
                    f"https://{host}/api/get-torrents",
                    params={"imdb_id": imdb_id, "limit": "100", "page": "1"},
                    headers={"Accept": "application/json"},
                )
                response.raise_for_status()
                parsed = response.json()
                if isinstance(parsed, dict):
                    payload = parsed
                    break
            except (httpx.HTTPError, ValueError):
                continue

    if not payload:
        return []

    results: list[dict[str, Any]] = []
    for item in payload.get("torrents") or []:
        if not isinstance(item, dict):
            continue
        h = str(item.get("hash") or "").strip().lower()
        if not re.fullmatch(r"[0-9a-f]{40}", h):
            continue
        title = str(item.get("filename") or item.get("title") or "").strip()
        if not title:
            continue
        magnet = str(item.get("magnet_url") or "").strip()
        if not magnet:
            magnet = f"magnet:?xt=urn:btih:{h}&dn={quote(title, safe='')}"
        try:
            from datetime import datetime, timezone
            published = datetime.fromtimestamp(
                int(item.get("date_released_unix") or 0), tz=timezone.utc
            ).isoformat() if item.get("date_released_unix") else ""
        except Exception:
            published = ""
        results.append({
            "guid": f"eztv-{h}",
            "title": title,
            "size": int(float(item.get("size_bytes") or 0)),
            "seeders": int(item.get("seeds") or 0),
            "leechers": int(item.get("peers") or 0),
            "indexer": "eztv.yt",
            "protocol": "torrent",
            "publishDate": published,
            "magnetUrl": magnet,
            "infoHash": h,
            "downloadUrl": magnet,
            "infoUrl": "",
            "sourceUrl": "",
        })
    _, season, episode = _media_search_parts(query)
    if season is not None:
        results = [
            row for row in results
            if _season_episode_match(row["title"], season, episode)
        ]

    results.sort(
        key=lambda row: (row["seeders"] + row["leechers"], row["publishDate"]),
        reverse=True,
    )
    return results[:limit]


LIMETORRENTS_HOSTS = tuple(
    host.strip()
    for host in os.getenv(
        "LIMETORRENTS_HOSTS",
        "www.limetorrents.fun,www.limetorrents.lol,limetorrents.fun,limetorrents.lol",
    ).split(",")
    if host.strip()
)


def _limetorrents_rows(html_text: str, base_url: str) -> list[dict[str, str]]:
    """Parse LimeTorrents rows using the current table structure."""
    soup = BeautifulSoup(html_text or "", "html.parser")
    rows: list[dict[str, str]] = []
    seen: set[str] = set()

    # LimeTorrents result rows may be direct children of table.table2
    # rather than tbody children, and may not carry a bgcolor attribute.
    # Avoid relying on either HTML detail.
    for row in soup.select("table.table2 tr"):
        # Prefer the visible title link over the empty download-icon link.
        title_anchor = row.select_one(".tt-name a[href*='-torrent-']")
        if title_anchor is None:
            title_anchor = next(
                (
                    anchor
                    for anchor in row.select(".tt-name a[href]")
                    if anchor.get_text(" ", strip=True)
                    and str(anchor.get("href") or "").lower().endswith(".html")
                ),
                None,
            )
        if title_anchor is None:
            continue

        title = title_anchor.get_text(" ", strip=True)
        detail_href = str(title_anchor.get("href") or "").strip()
        if not title or not detail_href:
            continue

        # LimeTorrents exposes the BTIH hash on the small download-icon
        # link in the listing row. Prefer this hash so Prepare can submit a
        # real magnet to Seedr without relying only on a detail-page scrape.
        download_anchor = (
            row.select_one(".tt-name a.csprite_dl14[href]")
            or row.select_one(".tt-name a[href*='/download/']")
        )
        download_href = str(download_anchor.get("href") or "").strip() if download_anchor else ""
        hash_match = re.search(
            r"(?i)(?<![0-9a-f])([0-9a-f]{40})(?![0-9a-f])",
            download_href,
        )
        torrent_hash = hash_match.group(1).lower() if hash_match else ""
        magnet_url = ""
        if torrent_hash:
            magnet_url = f"magnet:?xt=urn:btih:{torrent_hash}&dn={quote(title, safe='')}"
            for tracker in (
                "udp://tracker.opentrackr.org:1337/announce",
                "udp://open.stealth.si:80/announce",
            ):
                magnet_url += "&tr=" + quote(tracker, safe="")

        seed_cell = row.select_one(".tdseed")
        leech_cell = row.select_one(".tdleech")
        seeders = "0"
        leechers = "0"
        if seed_cell is not None:
            match = re.search(r"\d[\d,]*", seed_cell.get_text(" ", strip=True))
            if match:
                seeders = match.group(0).replace(",", "")
        if leech_cell is not None:
            match = re.search(r"\d[\d,]*", leech_cell.get_text(" ", strip=True))
            if match:
                leechers = match.group(0).replace(",", "")

        cells = row.find_all("td")
        size = ""
        if len(cells) >= 3:
            match = re.search(r"([\d.]+\s*[KMGT]i?B)", cells[2].get_text(" ", strip=True), re.I)
            if match:
                size = match.group(1)
        if not size:
            match = re.search(r"([\d.]+\s*[KMGT]i?B)", row.get_text(" ", strip=True), re.I)
            if match:
                size = match.group(1)

        source_url = urljoin(base_url.rstrip("/") + "/", detail_href.lstrip("/"))
        key = source_url.lower()
        if key in seen:
            continue
        seen.add(key)

        rows.append({
            "title": title,
            "detail_url": source_url,
            "size": size,
            "seeders": seeders,
            "leechers": leechers,
            "info_hash": torrent_hash,
            "magnet_url": magnet_url,
        })

    return rows


async def search_limetorrents(
    query: str,
    limit: int = 50,
    pages: int = 2,
) -> list[dict[str, Any]]:
    if not _MANUAL_TORRENT_SEARCH.get():
        _record_cache_event("torrent_search", "blocked_prefilled_live_lookup")
        return []
    """Search LimeTorrents concurrently across mirrors; resolve magnets on demand."""
    _title_query, season, episode = _media_search_parts(query)
    provider_query = _media_provider_query(query)

    # Keep language terms in the provider query so "thor hindi" searches the
    # Hindi result pool directly instead of searching only for "thor".
    _, languages = _search_query_constraints(query)
    language_terms = [
        language
        for language in languages
        if language in {
            "hindi", "tamil", "telugu", "malayalam", "kannada",
            "bengali", "marathi", "punjabi", "gujarati", "urdu",
        }
    ]
    provider_query = re.sub(
        r"\s+",
        " ",
        f"{provider_query} {' '.join(language_terms)}".strip(),
    )
    if not provider_query:
        return []

    category = "tv" if season is not None or episode is not None else "movies"
    encoded = quote(provider_query, safe="")
    headers = {
        "User-Agent": "Mozilla/5.0 (X11; Linux aarch64) AppleWebKit/537.36 Chrome/126.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }

    async with _InstrumentedAsyncClient(
        timeout=SEARCH_SOURCE_TIMEOUT_SECONDS,
        follow_redirects=True,
        headers=headers,
    ) as client:
        async def fetch_host(host: str) -> list[tuple[str, str]]:
            base = f"https://{host}"
            urls = [f"{base}/search/all/{encoded}/seeds/1/"]
            if pages > 1:
                urls.append(f"{base}/search/all/{encoded}/seeds/2/")

            async def fetch_page(url: str) -> str:
                try:
                    async with _LIMETORRENTS_REQUEST_SEMAPHORE:
                        response = await client.get(url)
                    if response.status_code < 400 and response.text:
                        return response.text
                except httpx.HTTPError:
                    pass
                return ""

            bodies = await asyncio.gather(
                *(fetch_page(url) for url in urls),
                return_exceptions=False,
            )
            return [(base, body) for body in bodies if body]

        # Probe all mirrors together. Previously a dead first mirror could
        # consume the timeout sequentially before a healthy mirror was tried.
        mirror_pages = await asyncio.gather(
            *(fetch_host(host) for host in LIMETORRENTS_HOSTS),
            return_exceptions=True,
        )
        pages_html: list[tuple[str, str]] = []
        for value in mirror_pages:
            if isinstance(value, list):
                pages_html.extend(value)

        raw_rows: list[dict[str, str]] = []
        for base, html_text in pages_html:
            raw_rows.extend(_limetorrents_rows(html_text, base))

        if not raw_rows:
            logger.warning(
                "LimeTorrents unavailable for '%s' (hosts=%s)",
                query,
                ",".join(LIMETORRENTS_HOSTS),
            )
            return []

        units = {
            "KB": 1024, "KIB": 1024,
            "MB": 1024**2, "MIB": 1024**2,
            "GB": 1024**3, "GIB": 1024**3,
            "TB": 1024**4, "TIB": 1024**4,
        }

        # Merge repeated rows from mirror domains, retaining the highest
        # reported seed/peer counts for each title and size.
        unique_rows: dict[tuple[str, str], dict[str, Any]] = {}
        for row in raw_rows:
            size_match = re.match(r"([\d.]+)\s*([KMGT]i?B)", row.get("size", ""), re.I)
            if not size_match:
                continue
            size = int(float(size_match.group(1)) * units[size_match.group(2).upper()])
            key = (_normalize_title(str(row.get("title") or "")), str(size))
            candidate = {**row, "size_bytes": size}
            previous = unique_rows.get(key)
            if previous is None or (
                int(candidate.get("seeders") or 0), int(candidate.get("leechers") or 0)
            ) > (
                int(previous.get("seeders") or 0), int(previous.get("leechers") or 0)
            ):
                unique_rows[key] = candidate

        parsed_rows = list(unique_rows.values())
        parsed_rows.sort(
            key=lambda row: (
                int(row.get("seeders") or 0),
                int(row.get("leechers") or 0),
            ),
            reverse=True,
        )

        results: list[dict[str, Any]] = []
        for row in [r for r in parsed_rows if _in_size_window(r.get("size_bytes"), query)][:min(max(limit, 1), 30)]:
            detail_url = str(row.get("detail_url") or "").strip()
            if not detail_url:
                continue
            results.append({
                "guid": "limetorrents-" + hashlib.sha1(detail_url.encode("utf-8")).hexdigest()[:20],
                "title": str(row.get("title") or ""),
                "size": int(row.get("size_bytes") or 0),
                "seeders": int(row.get("seeders") or 0),
                "leechers": int(row.get("leechers") or 0),
                "indexer": "LimeTorrents",
                "protocol": "torrent",
                "publishDate": "",
                "magnetUrl": str(row.get("magnet_url") or "").strip() or None,
                "infoHash": str(row.get("info_hash") or "").strip(),
                "downloadUrl": str(row.get("magnet_url") or "").strip() or None,
                "infoUrl": detail_url,
                "sourceUrl": detail_url,
                "descriptorUrl": "",
                "category": "TV" if category == "tv" else "Movies",
            })

    logger.warning(
        "LimeTorrents listing '%s': %d results; top seeders=%s",
        query,
        len(results),
        ",".join(str(item.get("seeders") or 0) for item in results[:5]),
    )
    return results[:limit]


async def search_knaben(
    query: str,
    limit: int = 100,
    provider_query: str | None = None,
) -> list[dict[str, Any]]:
    if not _MANUAL_TORRENT_SEARCH.get():
        _record_cache_event("torrent_search", "blocked_prefilled_live_lookup")
        return []
    """Search Knaben API v2 using its edge-cached GET interface."""
    title_query, season, episode = _media_search_parts(query)
    title_query = re.sub(r"\s+", " ", provider_query or _media_provider_query(query)).strip()
    if not title_query:
        return []

    target_tokens = _search_tokens(title_query)
    # Knaben API v2 moved search to GET /v2/search and renamed the parameters.
    # Accept an older /v1 environment override but transparently upgrade it.
    endpoint = KNABEN_API_URL.rstrip("/")
    if endpoint.endswith("/v1"):
        endpoint = endpoint[:-3] + "/v2/search"
    elif endpoint.endswith("/v2"):
        endpoint += "/search"
    elif endpoint in {"https://api.knaben.org", "http://api.knaben.org"}:
        endpoint += "/v2/search"

    params = {
        "q": title_query,
        "sf": "title",
        "o": "seeders",
        "d": "desc",
        "s": min(max(int(limit or 100), 1), 150),
        "f": 0,
        "seen": 604800,
    }

    try:
        # v2 is edge-cached, but give it a little more than the old 2.25s v1
        # budget: the latter was consistently timing out in Home's live logs.
        timeout = httpx.Timeout(max(7.0, SEARCH_SOURCE_TIMEOUT_SECONDS), connect=6.0)
        async with _InstrumentedAsyncClient(timeout=timeout, follow_redirects=True) as client:
            async with _KNABEN_REQUEST_SEMAPHORE:
                response = await client.get(
                    endpoint,
                    params=params,
                    headers={"Accept": "application/json", "User-Agent": "HomeMovieSearch/1.0"},
                )
            response.raise_for_status()
            payload = response.json()
            raw_hits = payload if isinstance(payload, list) else (
                payload.get("hits", []) if isinstance(payload, dict) else []
            )
            logger.info(
                "Knaben v2 HTTP %s for '%s': %d hits",
                response.status_code,
                query,
                len(raw_hits) if isinstance(raw_hits, list) else 0,
            )
    except (httpx.HTTPError, ValueError) as exc:
        # Include the exception type because timeout exceptions often have an
        # empty string, which made the previous production logs unhelpful.
        logger.warning(
            "Knaben v2 search failed for '%s': %s: %r",
            query,
            type(exc).__name__,
            str(exc),
        )
        return []

    if not isinstance(raw_hits, list):
        return []

    results: list[dict[str, Any]] = []
    for hit in raw_hits:
        if not isinstance(hit, dict):
            continue

        title = str(hit.get("title") or "").strip()
        category = str(hit.get("category") or "").strip()
        if not title:
            continue

        normalized_title = _normalize_title(title)
        if target_tokens and not all(token in normalized_title for token in target_tokens):
            continue
        if category and any(
            blocked in category.lower()
            for blocked in ("anime", "games", "music", "software", "books", "porn", "xxx", "adult")
        ):
            continue
        if category and not any(
            allowed in category.lower()
            for allowed in ("video", "movie", "tv", "television", "series")
        ):
            continue
        if season is not None and not _season_episode_match(title, season, episode):
            continue

        magnet = str(hit.get("magnetUrl") or hit.get("magnet_url") or "").strip()
        h = str(hit.get("hash") or hit.get("infoHash") or hit.get("info_hash") or "").strip().lower()
        if not re.fullmatch(r"[0-9a-f]{40}", h):
            h = info_hash(magnet)
        if not magnet and re.fullmatch(r"[0-9a-f]{40}", h):
            magnet = f"magnet:?xt=urn:btih:{h}&dn={quote(title, safe='')}"

        try:
            size = int(hit.get("bytes") or hit.get("size_bytes") or hit.get("size") or 0)
        except (TypeError, ValueError):
            size = 0
        try:
            seeders = int(hit.get("seeders") or hit.get("seeds") or 0)
        except (TypeError, ValueError):
            seeders = 0
        try:
            leechers = int(hit.get("peers") or hit.get("leechers") or 0)
        except (TypeError, ValueError):
            leechers = 0

        detail_url = str(hit.get("details") or hit.get("infoUrl") or "").strip()
        descriptor_url = str(hit.get("link") or hit.get("descriptorUrl") or "").strip()
        tracker = str(hit.get("cachedOrigin") or hit.get("tracker") or hit.get("trackerId") or "Knaben").strip()
        published = str(hit.get("date") or hit.get("publishDate") or "").strip()

        results.append({
            "guid": f"knaben-{h or hit.get('id') or title}",
            "title": title,
            "size": size,
            "seeders": seeders,
            "leechers": leechers,
            "indexer": tracker,
            "protocol": "torrent",
            "publishDate": published,
            "magnetUrl": magnet or None,
            "infoHash": h if re.fullmatch(r"[0-9a-f]{40}", h, re.I) else "",
            "downloadUrl": magnet or None,
            "infoUrl": detail_url,
            "sourceUrl": detail_url or descriptor_url,
            "descriptorUrl": descriptor_url,
            "category": category,
        })

    results = [row for row in results if _in_size_window(row.get("size"), query)]
    results.sort(
        key=lambda row: (
            1 if _normalize_title(str(row["title"])).startswith(_normalize_title(title_query)) else 0,
            int(row.get("seeders") or 0),
        ),
        reverse=True,
    )
    logger.info("Knaben v2 search '%s': %d relevant results after title/category filtering", query, len(results))
    return results[:limit]


# --- Prowlarr (optional) -----------------------------------------------------------------------------------------
# 1337x refuses many datacenter addresses (HTTP 403). A Prowlarr + FlareSolverr pair on the same machine can still read it.
# Set PROWLARR_URL (e.g. http://host.docker.internal:9696) and PROWLARR_API_KEY to add it as one more search source.
PROWLARR_URL = os.getenv("PROWLARR_URL", "").strip().rstrip("/")
PROWLARR_API_KEY = os.getenv("PROWLARR_API_KEY", "").strip()
_PROWLARR_HASHES: dict[str, str] = {}          # download link -> info hash ("" = could not be resolved)
_PROWLARR_RESOLVE_SEMAPHORE = asyncio.Semaphore(3)
_PROWLARR_BACKGROUND: set[asyncio.Task] = set()


async def _prowlarr_resolve_hash(download_url: str) -> str:
    """Follow Prowlarr's download link once: for a magnet release it answers with a redirect to the magnet."""
    if download_url in _PROWLARR_HASHES:
        return _PROWLARR_HASHES[download_url]
    digest = ""
    try:
        async with _PROWLARR_RESOLVE_SEMAPHORE:
            async with _InstrumentedAsyncClient(timeout=45, follow_redirects=False) as client:
                response = await client.get(download_url, headers={"X-Api-Key": PROWLARR_API_KEY})
        location = response.headers.get("location") or ""
        if location.startswith("magnet:"):
            digest = info_hash(location)
        if not re.fullmatch(r"[0-9a-f]{40}", digest or "", re.I):
            digest = ""
    except httpx.HTTPError as exc:
        logger.info("Prowlarr link could not be resolved: %s", type(exc).__name__)
    if digest:
        _PROWLARR_HASHES[download_url] = digest.lower()
    return digest.lower()


async def search_prowlarr(query: str, limit: int = 50, provider_query: str | None = None, wait: bool = False) -> list[dict[str, Any]]:
    """Search through Prowlarr. A release is listed only once its magnet is known: with ``wait`` (the cache scan) the
    hashes are resolved before answering; otherwise they are resolved in the background and appear on the next search."""
    if not (PROWLARR_URL and PROWLARR_API_KEY):
        return []
    if not _MANUAL_TORRENT_SEARCH.get():
        _record_cache_event("torrent_search", "blocked_prefilled_live_lookup")
        return []
    _, season, episode = _media_search_parts(query)
    title_query = re.sub(r"\s+", " ", provider_query or _media_provider_query(query)).strip()
    if not title_query:
        return []
    target_tokens = _search_tokens(title_query)
    try:
        async with _InstrumentedAsyncClient(timeout=httpx.Timeout(60.0, connect=6.0)) as client:
            response = await client.get(
                f"{PROWLARR_URL}/api/v1/search",
                params={"query": title_query, "type": "search", "limit": 100},
                headers={"X-Api-Key": PROWLARR_API_KEY, "Accept": "application/json"},
            )
        response.raise_for_status()
        hits = response.json()
    except (httpx.HTTPError, ValueError) as exc:
        logger.warning("Prowlarr search failed for '%s': %s: %r", query, type(exc).__name__, str(exc))
        return []
    if not isinstance(hits, list):
        return []

    candidates: list[dict[str, Any]] = []
    for hit in hits:
        if not isinstance(hit, dict):
            continue
        title = str(hit.get("title") or "").strip()
        if not title:
            continue
        if target_tokens and not all(token in _normalize_title(title) for token in target_tokens):
            continue
        if season is not None and not _season_episode_match(title, season, episode):
            continue
        candidates.append(hit)
    candidates.sort(key=lambda hit: int(hit.get("seeders") or 0), reverse=True)

    def digest_of(hit: dict[str, Any]) -> str:
        magnet = str(hit.get("magnetUrl") or "").strip()
        value = str(hit.get("infoHash") or "").strip().lower()
        if not re.fullmatch(r"[0-9a-f]{40}", value):
            value = info_hash(magnet) if magnet else ""
        if not re.fullmatch(r"[0-9a-f]{40}", value or ""):
            value = _PROWLARR_HASHES.get(str(hit.get("downloadUrl") or ""), "")
        return value or ""

    pending = [hit for hit in candidates[:12] if not digest_of(hit) and hit.get("downloadUrl")]
    if pending:
        tasks = [asyncio.ensure_future(_prowlarr_resolve_hash(str(hit["downloadUrl"]))) for hit in pending]
        if wait:
            await asyncio.gather(*tasks, return_exceptions=True)
        else:
            for task in tasks:               # keep going after this request ends; the next search finds the hashes
                _PROWLARR_BACKGROUND.add(task)
                task.add_done_callback(_PROWLARR_BACKGROUND.discard)

    results: list[dict[str, Any]] = []
    for hit in candidates:
        digest = digest_of(hit)
        if not digest:
            continue
        title = str(hit.get("title") or "").strip()
        try:
            size = int(hit.get("size") or 0)
        except (TypeError, ValueError):
            size = 0
        if not _in_size_window(size, query):
            continue
        magnet = f"magnet:?xt=urn:btih:{digest}&dn={quote(title, safe='')}"
        detail = str(hit.get("infoUrl") or "").strip()
        results.append({
            "guid": f"prowlarr-{digest}",
            "title": title,
            "size": size,
            "seeders": int(hit.get("seeders") or 0),
            "leechers": int(hit.get("leechers") or 0),
            "indexer": str(hit.get("indexer") or "Prowlarr"),
            "protocol": "torrent",
            "publishDate": str(hit.get("publishDate") or ""),
            "magnetUrl": magnet,
            "infoHash": digest,
            "downloadUrl": magnet,
            "infoUrl": detail,
            "sourceUrl": detail,
            "category": "",
        })
    logger.info("Prowlarr search '%s': %d usable results (%d still resolving)", query, len(results), len(pending) if not wait else 0)
    return results[:limit]



async def search_torrents_csv(query: str, limit: int) -> dict[str, Any]:
    if not _MANUAL_TORRENT_SEARCH.get():
        _record_cache_event("torrent_search", "blocked_prefilled_live_lookup")
        return {"source": "torrents-csv", "elapsedMs": 0, "results": []}
    started = time.monotonic()
    try:
        async with _InstrumentedAsyncClient(timeout=SEARCH_SOURCE_TIMEOUT_SECONDS, follow_redirects=True) as client:
            response = await client.get(
                "https://torrents-csv.com/service/search",
                params={
                    "q": _media_provider_query(query),
                    "size": min(limit, 50),
                    "type": "torrent",
                },
                headers={"Accept": "application/json", "User-Agent": "TorrentStudio/1.0"},
            )
            response.raise_for_status()
            payload = response.json()

        rows = payload if isinstance(payload, list) else (
            payload.get("torrents", []) if isinstance(payload, dict) else []
        )
        results: list[dict[str, Any]] = []
        for item in rows:
            if not isinstance(item, dict):
                continue
            h = str(item.get("infohash") or "").strip().lower()
            if not re.fullmatch(r"[0-9a-f]{40}", h):
                continue
            title = str(item.get("name") or "Untitled").strip()
            if not title or not _in_size_window(item.get("size_bytes"), query):
                continue
            results.append({
                "guid": f"torrents-csv-{h}",
                "title": title,
                "size": int(float(item.get("size_bytes") or 0)),
                "seeders": int(item.get("seeders") or 0),
                "leechers": int(item.get("leechers") or 0),
                "indexer": "torrents-csv",
                "protocol": "torrent",
                "publishDate": (
                    datetime.fromtimestamp(
                        int(item.get("created_unix") or 0), tz=timezone.utc
                    ).isoformat()
                    if item.get("created_unix") else ""
                ),
                "infoHash": h,
                "magnetUrl": f"magnet:?xt=urn:btih:{h}&dn={quote(title, safe='')}",
                "downloadUrl": f"magnet:?xt=urn:btih:{h}&dn={quote(title, safe='')}",
                "infoUrl": "",
                "sourceUrl": "",
                "descriptorUrl": "",
            })
        return {"source": "torrents-csv", "elapsedMs": round((time.monotonic() - started) * 1000), "results": results}
    except (httpx.HTTPError, ValueError, TypeError) as exc:
        logger.info("Torrents-CSV search failed for '%s': %s", query, exc)
        return {"source": "torrents-csv", "elapsedMs": round((time.monotonic() - started) * 1000), "results": [], "error": str(exc)}


async def search_apibay(query: str, limit: int) -> dict[str, Any]:
    if not _MANUAL_TORRENT_SEARCH.get():
        _record_cache_event("torrent_search", "blocked_prefilled_live_lookup")
        return {"source": "apibay", "elapsedMs": 0, "results": []}
    started = time.monotonic()
    try:
        async with _InstrumentedAsyncClient(timeout=SEARCH_SOURCE_TIMEOUT_SECONDS, follow_redirects=True) as client:
            response = await client.get(
                "https://apibay.org/q.php",
                params={"q": _media_provider_query(query), "cat": "0"},
                headers={"Accept": "application/json", "User-Agent": "TorrentStudio/1.0"},
            )
            response.raise_for_status()
            payload = response.json()

        rows = payload if isinstance(payload, list) else []
        results: list[dict[str, Any]] = []
        for item in rows:
            if len(results) >= limit:
                break
            if not isinstance(item, dict):
                continue
            h = str(item.get("info_hash") or "").strip().lower()
            if not re.fullmatch(r"[0-9a-f]{40}", h):
                continue
            title = str(item.get("name") or "Untitled").strip()
            if not title or not _in_size_window(item.get("size"), query):
                continue
            results.append({
                "guid": f"apibay-{h}",
                "title": title,
                "size": int(float(item.get("size") or 0)),
                "seeders": int(item.get("seeders") or 0),
                "leechers": int(item.get("leechers") or 0),
                "indexer": "apibay",
                "protocol": "torrent",
                "publishDate": "",
                "infoHash": h,
                "magnetUrl": f"magnet:?xt=urn:btih:{h}&dn={quote(title, safe='')}",
                "downloadUrl": f"magnet:?xt=urn:btih:{h}&dn={quote(title, safe='')}",
                "infoUrl": "",
                "sourceUrl": "",
                "descriptorUrl": "",
            })
        return {"source": "apibay", "elapsedMs": round((time.monotonic() - started) * 1000), "results": results}
    except (httpx.HTTPError, ValueError, TypeError) as exc:
        logger.info("APIBay search failed for '%s': %s", query, exc)
        return {"source": "apibay", "elapsedMs": round((time.monotonic() - started) * 1000), "results": [], "error": str(exc)}


def _search_media_kind(query: str) -> str:
    """Classify only enough to select strict media sources; never opens generic categories."""
    q = query.strip()
    if re.search(r"\b(?:S\d{1,2}(?:E\d{1,3})?|season\s*\d+|episode\s*\d+)\b", q, re.I):
        return "tv"
    return "both"


def _expand_compound_search_title(value: str) -> str:
    title = str(value or "")
    for compact, canonical in SEARCH_COMPOUND_ALIASES.items():
        title = re.sub(
            rf"(?<![a-z]){re.escape(compact)}(?![a-z])",
            canonical,
            title,
            flags=re.I,
        )
    return title


def _media_provider_query(value: str) -> str:
    """Return the title portion used for provider searches, excluding qualifiers."""
    title, _season, _episode = _media_search_parts(value)
    _year, languages = _search_query_constraints(value)
    for language in sorted(languages, key=len, reverse=True):
        title = re.sub(
            rf"(?<![a-z]){re.escape(language)}(?![a-z])",
            " ",
            title,
            flags=re.I,
        )
    title = _expand_compound_search_title(title)
    title = re.sub(r"\bspider[- ]?man\b", "spider man", title, flags=re.I)
    title = re.sub(r"\bant[- ]?man\b", "ant man", title, flags=re.I)
    return re.sub(r"\s+", " ", title).strip()


def _search_query_constraints(value: str) -> tuple[int | None, list[str]]:
    """Extract constraints that should affect matching but not title search."""
    years = re.findall(r"\b((?:19|20)\d{2})\b", value)
    year = int(years[-1]) if years else None

    language_aliases = (
        "hindi", "tamil", "telugu", "malayalam", "kannada",
        "bengali", "marathi", "punjabi", "gujarati", "urdu",
        "dual audio", "multi audio", "dubbed", "dub",
    )
    lower = value.lower()
    languages = [term for term in language_aliases if re.search(
        rf"(?<![a-z]){re.escape(term)}(?![a-z])", lower
    )]
    return year, languages


def _constraint_matches_title(title: str, query: str) -> bool:
    """Match year/language qualifiers without making normal title search brittle."""
    year, languages = _search_query_constraints(query)
    normalized = _normalize_title(title)
    lower = title.lower()

    if year is not None:
        title_years = {int(value) for value in re.findall(r"\b((?:19|20)\d{2})\b", title)}
        if year not in title_years:
            return False

    language_aliases = {
        "hindi": (r"(?<![a-z])hindi(?![a-z])", r"(?<![a-z])hin(?![a-z])"),
        "tamil": (r"(?<![a-z])tamil(?![a-z])", r"(?<![a-z])tam(?![a-z])"),
        "telugu": (r"(?<![a-z])telugu(?![a-z])", r"(?<![a-z])tel(?![a-z])"),
        "malayalam": (r"(?<![a-z])malayalam(?![a-z])", r"(?<![a-z])mal(?![a-z])"),
        "kannada": (r"(?<![a-z])kannada(?![a-z])", r"(?<![a-z])kan(?![a-z])"),
        "bengali": (r"(?<![a-z])bengali(?![a-z])", r"(?<![a-z])ben(?![a-z])"),
        "marathi": (r"(?<![a-z])marathi(?![a-z])", r"(?<![a-z])mar(?![a-z])"),
        "punjabi": (r"(?<![a-z])punjabi(?![a-z])", r"(?<![a-z])pun(?![a-z])"),
        "gujarati": (r"(?<![a-z])gujarati(?![a-z])", r"(?<![a-z])guj(?![a-z])"),
        "urdu": (r"(?<![a-z])urdu(?![a-z])", r"(?<![a-z])urd(?![a-z])"),
    }

    for language in languages:
        patterns = language_aliases.get(language)
        if patterns:
            if not any(re.search(pattern, lower, re.I) for pattern in patterns):
                return False
        elif language not in lower and language.replace(" ", "") not in normalized.replace(" ", ""):
            return False

    return True


def _search_quality_filter(item: dict[str, Any], query: str) -> bool:
    """Hard media/size gate plus title and qualifier relevance."""
    title = str(item.get("title") or "").strip()
    if not title:
        return False

    normalized = _normalize_title(title)
    normalized_tokens = set(normalized.split())
    _query_title, season, episode = _media_search_parts(query)
    # Language/codec/year qualifiers are validated separately below. The title
    # matcher should use only the actual media title, otherwise a release using
    # "Hin"/"Dub" instead of the exact query word "Hindi" gets discarded even
    # though the provider found it correctly.
    provider_title = _media_provider_query(query)
    target_tokens = _search_tokens(provider_title)

    # Match whole normalized tokens, not arbitrary substrings. This keeps
    # "thor" from matching "Thoroughbreds" while allowing punctuation variants
    # such as "Spider-Man" / "Spider Man" after title normalization.
    if target_tokens and not all(token in normalized_tokens for token in target_tokens):
        return False

    if not _constraint_matches_title(title, query):
        return False

    if season is not None and not _season_episode_match(title, season, episode):
        return False

    category = str(item.get("category") or "").lower()
    blocked = (
        "game", "software", "application", "music", "audio",
        "book", "ebook", "porn", "xxx", "adult", "anime",
    )
    if any(word in category for word in blocked):
        return False

    size = int(item.get("size") or 0)
    return _in_size_window(size, query)


def _title_relevance(title: str, query: str) -> tuple[int, int]:
    """Prefer titles that begin with the searched title, ignoring leading articles."""
    normalized = _normalize_title(title)
    target = _normalize_title(_media_search_parts(query)[0])
    if not target:
        return (0, 0)

    # Indexers often add "The" before a movie title. Do not demote an otherwise
    # direct match just because the article is present.
    candidate = re.sub(r"^(?:the|a|an)\s+", "", normalized)
    if candidate == target:
        return (4, len(target))
    if candidate.startswith(target + " "):
        return (3, len(target))

    candidate_tokens = candidate.split()
    target_tokens = target.split()
    if not target_tokens:
        return (0, 0)

    # Exact consecutive title tokens anywhere in the name are better than
    # tokens that only happen to appear in a longer related title (e.g. LEGO).
    for index in range(max(0, len(candidate_tokens) - len(target_tokens) + 1)):
        if candidate_tokens[index:index + len(target_tokens)] == target_tokens:
            return (2, len(target))
    if all(token in candidate_tokens for token in target_tokens):
        return (1, len(target))
    return (0, 0)


def _release_quality_score(title: str) -> int:
    """Estimate release quality from common filename tags; not a safety/trust score."""
    lower = unescape(str(title or "")).lower()
    score = 0

    # Resolution is a strong, broadly available signal.
    if re.search(r"\b(?:2160p|4k|uhd)\b", lower):
        score += 8
    elif re.search(r"\b1080p\b", lower):
        score += 6
    elif re.search(r"\b720p\b", lower):
        score += 4
    elif re.search(r"\b480p\b", lower):
        score += 2

    # Prefer modern digital/Blu-ray sources over older disc rips.
    if re.search(r"\b(?:blu[ .-]?ray|bdrip|brrip|remux)\b", lower):
        score += 4
    elif re.search(r"\b(?:web[ .-]?dl|webdl|webrip)\b", lower):
        score += 3
    elif re.search(r"\bhdtv\b", lower):
        score += 2
    elif re.search(r"\b(?:dvdrip|dvd)\b", lower):
        score += 1

    if re.search(r"\b(?:x265|h265|hevc|av1)\b", lower):
        score += 1
    if re.search(r"\b(?:x264|h264)\b", lower):
        score += 1
    if re.search(r"\b(?:hdr10?|dolby[ .]?vision|10bit)\b", lower):
        score += 1

    # Strongly demote low-quality theatrical captures and screeners without
    # removing them, so users can still find smaller/older releases if needed.
    if re.search(r"\b(?:hdcam|camrip|cam|telesync|telecine|ts|dvdscr|screener)\b", lower):
        score -= 8
    elif re.search(r"\br5\b", lower):
        score -= 2

    return score


def _media_provider_queries(value: str) -> list[str]:
    """Build a tiny title-variant set without exploding provider traffic.

    The first query is canonicalized (e.g. Spider-Man -> Spider Man). A second
    spelling is used only when the fast path returns too few usable results.
    For long titles, a third short anchor can recover indexers that struggle
    with punctuation while local filtering still requires the full user query.
    """
    title, _season, _episode = _media_search_parts(value)
    _year, languages = _search_query_constraints(value)

    raw_title = title
    for language in sorted(languages, key=len, reverse=True):
        raw_title = re.sub(
            rf"(?<![a-z]){re.escape(language)}(?![a-z])",
            " ",
            raw_title,
            flags=re.I,
        )
    raw_title = re.sub(r"\s+", " ", raw_title).strip()

    canonical = _media_provider_query(value)
    language_terms = [
        language for language in languages
        if language in {
            "hindi", "tamil", "telugu", "malayalam", "kannada",
            "bengali", "marathi", "punjabi", "gujarati", "urdu",
        }
    ]
    language_suffix = " ".join(language_terms)
    canonical_with_language = re.sub(
        r"\s+",
        " ",
        f"{canonical} {language_suffix}".strip(),
    )

    variants: list[str] = []
    seen: set[str] = set()
    for candidate in (
        canonical_with_language,
        canonical,
        raw_title,
        f"{raw_title} {language_suffix}".strip(),
    ):
        candidate = re.sub(r"\s+", " ", candidate or "").strip()
        lowered = candidate.lower()
        if candidate and lowered not in seen:
            seen.add(lowered)
            variants.append(candidate)

    tokens = _search_tokens(raw_title)
    if len(tokens) >= 4:
        anchor = " ".join(tokens[:3])
        if anchor and anchor.lower() not in {x.lower() for x in variants}:
            variants.append(anchor)

    return variants[:3]


def _search_cache_key(query: str) -> str:
    key = re.sub(r"\s+", " ", query.strip()).lower()
    # Results searched without the size window must never be served to (or taken from) the normal window.
    if _SEARCH_SOURCE.get() != "all":
        key = _SEARCH_SOURCE.get() + "|" + key
    return "any-size|" + key if _SIZE_WINDOW_DISABLED.get() else key


def _trim_search_cache() -> None:
    while len(_search_cache) > max(10, SEARCH_CACHE_MAX_ENTRIES):
        oldest_key = min(
            _search_cache.items(),
            key=lambda pair: pair[1][0],
        )[0]
        _search_cache.pop(oldest_key, None)


async def _search_1337x_uncached(
    query: str,
    allow_series_fallback: bool = True,
) -> list[dict[str, Any]]:
    if not _MANUAL_TORRENT_SEARCH.get():
        _record_cache_event("torrent_search", "blocked_prefilled_live_lookup")
        return []
    """Perform one bounded live media search.

    This is intentionally conservative for Render Free: only the primary
    1337x/Knaben pair runs on the first pass. More expensive alternate queries
    and specialist providers are activated only when fewer than 8 usable
    results survive the hard media and configured size gates.
    """
    limit = 50
    kind = _search_media_kind(query)
    variants = _media_provider_queries(query)
    primary_provider_query = variants[0] if variants else _media_provider_query(query)

    if _SEARCH_SOURCE.get() == "prowlarr":
        try:
            found = await asyncio.wait_for(
                search_prowlarr(query, 50, provider_query=primary_provider_query, wait=True), timeout=150.0)
        except Exception as exc:
            logger.info("Prowlarr-only search failed for '%s': %s", query, exc)
            found = []
        return [item for item in found if _search_quality_filter(item, query)]

    async def run_1337x(provider_query: str):
        try:
            return await asyncio.wait_for(
                search_1337x_direct(
                    query,
                    limit=20,
                    pages=2,
                    category="TV" if kind == "tv" else None,
                    provider_query=provider_query,
                ),
                timeout=max(8.0, SEARCH_TOTAL_TIMEOUT_SECONDS + 4.0),
            )
        except Exception as exc:
            logger.warning("1337x search failed for '%s' using '%s': %s: %r", query, provider_query, type(exc).__name__, str(exc))
            return []

    async def run_lime(provider_query: str):
        try:
            lime_results = await asyncio.wait_for(
                search_limetorrents(
                    query,
                    limit=20,
                    pages=1,
                ),
                timeout=10.0,
            )
            logger.warning(
                "LimeTorrents primary source '%s': %d results",
                query,
                len(lime_results),
            )
            return lime_results
        except Exception as exc:
            logger.warning(
                "LimeTorrents search failed for '%s' using '%s': %s: %s",
                query,
                provider_query,
                type(exc).__name__,
                str(exc) or "<no message>",
            )
            return []

    async def run_knaben(provider_query: str):
        try:
            return await asyncio.wait_for(
                search_knaben(query, 50, provider_query=provider_query),
                timeout=8.0,
            )
        except Exception as exc:
            logger.info("Knaben search failed for '%s' using '%s': %s", query, provider_query, exc)
            return []

    yts_task = (
        asyncio.create_task(
            asyncio.wait_for(
                search_yts_movies(query, min(limit, 20)),
                timeout=SEARCH_SOURCE_TIMEOUT_SECONDS + 0.75,
            )
        )
        if kind == "both"
        else None
    )

    async def run_prowlarr(provider_query: str):
        try:
            # A live search lists the magnets Prowlarr already resolved and keeps resolving the rest in the background.
            return await asyncio.wait_for(
                search_prowlarr(query, 50, provider_query=provider_query, wait=False), timeout=15.0)
        except Exception as exc:
            logger.info("Prowlarr search failed for '%s': %s", query, exc)
            return []

    primary_1337x, primary_lime, primary_knaben = await asyncio.gather(
        run_1337x(primary_provider_query),
        run_lime(primary_provider_query),
        run_knaben(primary_provider_query),
        return_exceptions=False,
    )

    yts_primary: list[dict[str, Any]] = []
    if yts_task is not None:
        try:
            yts_primary = await yts_task
        except Exception as exc:
            logger.warning("YTS primary search failed for '%s': %s: %r", query, type(exc).__name__, str(exc))

    logger.warning(
        "Raw search source counts for '%s': 1337x=%d, LimeTorrents=%d, Knaben=%d, YTS=%d",
        query,
        len(primary_1337x),
        len(primary_lime),
        len(primary_knaben),
        len(yts_primary),
    )

    results: list[dict[str, Any]] = []

    def add_filtered(items: Any) -> None:
        if not isinstance(items, list):
            return
        for item in items:
            if _search_quality_filter(item, query):
                results.append(item)

    add_filtered(primary_1337x)
    add_filtered(primary_lime)
    add_filtered(primary_knaben)
    add_filtered(yts_primary)
    if not results and _SEARCH_SOURCE.get() == "all":
        # Nothing usable from the fast sources: ask Prowlarr (it reads 1337x when the site refuses this server).
        add_filtered(await run_prowlarr(primary_provider_query))

    yts_metadata: dict[str, dict[str, Any]] = {}
    for item in yts_primary:
        media_title = _normalize_title(str(item.get("mediaTitle") or ""))
        if media_title:
            yts_metadata.setdefault(media_title, item)

    def enrich_movie_metadata(items: list[dict[str, Any]]) -> None:
        for item in items:
            provider_title = str(item.get("mediaTitle") or item.get("title") or "")
            media_title = _normalize_title(_media_provider_query(provider_title))
            if not media_title:
                continue
            metadata = yts_metadata.get(media_title)
            if not metadata:
                compact = media_title.replace(" ", "")
                metadata = next(
                    (
                        candidate for key, candidate in yts_metadata.items()
                        if compact and key.replace(" ", "") == compact
                    ),
                    None,
                )
            if metadata:
                for field in ("mediaTitle", "year", "rating", "genres", "posterUrl"):
                    value = metadata.get(field)
                    if value not in (None, "", []):
                        item[field] = value

    enrich_movie_metadata(results)

    # When the primary title spelling cannot get enough usable hits, retry
    # with the alternate spelling and a short anchor in parallel. This is the
    # cheap way to handle Spider-Man/Spiderman-style provider differences
    # without always doubling Render traffic.
    if allow_series_fallback and len(results) < min(8, limit):
        secondary_queries = variants[1:3]

        variant_tasks = [
            asyncio.create_task(run_1337x(provider_query))
            for provider_query in secondary_queries
        ]
        variant_tasks.extend(
            asyncio.create_task(run_knaben(provider_query))
            for provider_query in secondary_queries
        )

        fallback_tasks: list[asyncio.Task] = [
            asyncio.create_task(
                search_torrents_csv(
                    query,
                    min(limit, 50),
                )
            ),
            asyncio.create_task(
                search_apibay(
                    query,
                    min(limit, 50),
                )
            ),
        ]

        if kind in {"tv", "both"}:
            fallback_tasks.append(
                asyncio.create_task(
                    asyncio.wait_for(
                        search_tv_eztv(query, min(limit, 20)),
                        timeout=SEARCH_SOURCE_TIMEOUT_SECONDS + 0.5,
                    )
                )
            )
        if kind == "both":
            fallback_tasks.append(
                asyncio.create_task(
                    asyncio.wait_for(
                        search_yts_movies(query, min(limit, 20)),
                        timeout=SEARCH_SOURCE_TIMEOUT_SECONDS + 0.5,
                    )
                )
            )

        values = await asyncio.gather(
            *(variant_tasks + fallback_tasks),
            return_exceptions=True,
        )
        for value in values:
            if isinstance(value, list):
                add_filtered(value)
            elif isinstance(value, dict):
                add_filtered(value.get("results", []))

        enrich_movie_metadata(results)

    merged: dict[str, dict[str, Any]] = {}
    for item in results:
        digest = str(item.get("infoHash") or "").strip().lower()
        if not re.fullmatch(r"[0-9a-f]{40}", digest):
            digest = info_hash(str(item.get("magnetUrl") or ""))

        if re.fullmatch(r"[0-9a-f]{40}", digest, re.I):
            key = "hash:" + digest.lower()
        else:
            # Listing-page results now resolve magnets lazily, so use a
            # normalized title + size to collapse the same release returned
            # by more than one provider.
            normalized_title = _normalize_title(str(item.get("title") or ""))
            if not normalized_title:
                continue
            size = int(item.get("size") or 0)
            key = f"title-size:{normalized_title}|{size}"

        previous = merged.get(key)
        if previous is None or (
            int(item.get("seeders") or 0),
            int(item.get("leechers") or 0),
            1 if item.get("magnetUrl") else 0,
        ) > (
            int(previous.get("seeders") or 0),
            int(previous.get("leechers") or 0),
            1 if previous.get("magnetUrl") else 0,
        ):
            merged[key] = item

    results = list(merged.values())
    enrich_movie_metadata(results)

    source_counts: dict[str, int] = {}
    for item in results:
        source_name = str(item.get("indexer") or "unknown").strip() or "unknown"
        source_counts[source_name] = source_counts.get(source_name, 0) + 1
    logger.warning(
        "Search result sources for '%s': %s",
        query,
        ", ".join(f"{name}={count}" for name, count in sorted(source_counts.items())),
    )

    # Poster artwork is resolved lazily by /api/poster so search latency is
    # unaffected. Every normal movie result gets a cleaned poster URL,
    # regardless of whether it came from YTS, Knaben, 1337x, or another source.
    if kind == "both":
        for item in results:
            if not str(item.get("posterUrl") or "").strip():
                poster_url = _poster_url_for_release(str(item.get("title") or ""))
                if poster_url:
                    item["posterUrl"] = poster_url

    # Do not let questionable seed counts from one indexer dominate the list.
    # Rank direct title matches first, then recognizable release quality, and
    # use swarm size/date as secondary signals within comparable results.
    results.sort(
        key=lambda item: (
            _title_relevance(str(item.get("title") or ""), query)[0],
            _release_quality_score(str(item.get("title") or "")),
            min(int(item.get("seeders") or 0), 5000),
            int(item.get("leechers") or 0),
            str(item.get("publishDate") or ""),
        ),
        reverse=True,
    )

    return results[:limit]


async def search_1337x(
    query: str,
    limit: int = 50,
    allow_series_fallback: bool = True,
) -> list[dict[str, Any]]:
    """Fast media-only search with stale cache and in-flight request sharing."""
    query = re.sub(r"\s+", " ", query.strip())
    if not query:
        return []

    limit = min(max(int(limit or 50), 1), 50)
    cache_key = _search_cache_key(query)
    now = time.monotonic()

    cached = _search_cache.get(cache_key)
    if cached and len(cached[1]) < SEARCH_CACHE_MIN_RESULTS:
        _search_cache.pop(cache_key, None)
        cached = None

    if cached:
        cached_at, cached_results = cached
        age = max(0.0, now - cached_at)
        ttl = SEARCH_CACHE_SECONDS

        if age < ttl:
            _record_cache_event("torrent_search", "hit")
            return cached_results[:limit]

        if age < SEARCH_CACHE_STALE_SECONDS:
            _record_cache_event("torrent_search", "stale_hit")
            # Serve stale results immediately and refresh only once per query.
            existing = _search_inflight.get(cache_key)
            if existing is None or existing.done():
                refresh = asyncio.create_task(
                    _search_1337x_uncached(
                        query,
                        allow_series_fallback=allow_series_fallback,
                    )
                )
                _search_inflight[cache_key] = refresh

                def _finish_refresh(task: asyncio.Task, key: str = cache_key):
                    _search_inflight.pop(key, None)
                    if task.cancelled():
                        return
                    try:
                        refreshed = task.result()
                    except Exception as exc:
                        logger.info("Background search refresh failed for '%s': %s", query, exc)
                        return
                    if len(refreshed) >= SEARCH_CACHE_MIN_RESULTS:
                        _search_cache[key] = (time.monotonic(), refreshed)
                        _trim_search_cache()

                refresh.add_done_callback(_finish_refresh)
            return cached_results[:limit]

    # Share the same live request among concurrent users. This is particularly
    # useful on Render Free where multiple browser tabs/devices can otherwise
    # fan out identical provider requests.
    _record_cache_event("torrent_search", "miss")
    task = _search_inflight.get(cache_key)
    if task is None or task.done():
        task = asyncio.create_task(
            _search_1337x_uncached(
                query,
                allow_series_fallback=allow_series_fallback,
            )
        )
        _search_inflight[cache_key] = task

    try:
        results = await task
    except asyncio.CancelledError:
        # The provider task may still be useful to other callers; do not leave
        # a dead task in the inflight map.
        if _search_inflight.get(cache_key) is task:
            _search_inflight.pop(cache_key, None)
        raise
    except Exception as exc:
        if _search_inflight.get(cache_key) is task:
            _search_inflight.pop(cache_key, None)
        logger.warning("Media search failed for '%s': %s", query, exc)
        return cached[1][:limit] if cached else []

    if _search_inflight.get(cache_key) is task:
        _search_inflight.pop(cache_key, None)

    if len(results) >= SEARCH_CACHE_MIN_RESULTS:
        _search_cache[cache_key] = (time.monotonic(), results)
        _trim_search_cache()
    return results[:limit]

def parse_size(value: str) -> int:
    m = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*(B|KB|MB|GB|TB)", value or "", re.I)
    if not m:
        return 0
    n = float(m.group(1))
    units = {"B": 1, "KB": 1024, "MB": 1024**2, "GB": 1024**3, "TB": 1024**4}
    return int(n * units[m.group(2).upper()])
